#include "Light.h"

	Light::Light() {
		this->specStr = 0.5f;
		this->specPhong = 16;
	}


